package br.com.exemplo.api.control;

import org.springframework.web.bind.annotation.RestController;
import br.com.exemplo.api.model.person;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PostMapping;





@RestController
public class Control 
{
    @GetMapping("")
    public String message() 
    {
        return "ola mundo java = C# menos bom";
    }
     
    @GetMapping("/hello")
    public String hello()  
    {
        return "Welcome";
    }

    @GetMapping("/hello/{name}")
    public String hello(@PathVariable String name)  
    {
        return "Welcome " + name;
    }

    @PostMapping("/pessoa")    
    public person human(@RequestBody person p)  
    {
        return p;
    }
}