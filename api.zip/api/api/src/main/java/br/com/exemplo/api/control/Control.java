package br.com.exemplo.api.control;

import org.springframework.web.bind.annotation.RestController;
import br.com.exemplo.api.model.person;
import br.com.exemplo.api.repository.repositorie;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;





@RestController
public class Control 
{
    @GetMapping("")
    public String message() 
    {
        return "ola mundo java = C# menos bom";
    }
     
    @GetMapping("/hello")
    public String hello()  
    {
        return "Welcome";
    }

    @GetMapping("/hello/{name}")
    public String hello(@PathVariable String name)  
    {
        return "Welcome " + name;
    }

    @PostMapping("/pessoa")    
    public person human(@RequestBody person p)  
    {
        return p;
    }

    @Autowired
    private repositorie action;

    @PostMapping("/api")
    public person cadastrar(@RequestBody person entity) 
    {                
        return action.save(entity);
    }  
    
    @GetMapping("/api")
    public List<person> select(@RequestBody person entity) 
    {                
        return action.findAll();
    }    

    @GetMapping("/api/{code}")
    public person selectby(@PathVariable int code) 
    {                
        return action.findBycode(code);
    }  

    @PutMapping("/api")
    public person edit(@RequestBody person entity) 
    {                
        return action.save(entity);
    }  

    @DeleteMapping("/api/{code}")
    public void remove(@PathVariable int code) 
    {                
        person object = selectby(code);
        action.delete(object);
    }  
}