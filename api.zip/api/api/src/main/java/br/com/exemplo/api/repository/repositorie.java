package br.com.exemplo.api.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import br.com.exemplo.api.model.person;


@Repository
public interface repositorie  extends CrudRepository< person, Integer>
{
    List<person> findAll();
    person findBycode(int code);
}
