const forM = document.querySelector('.form-chamado');
const button = document.querySelector('.btn-submit');

button.addEventListener('click', sign_CALL);

async function sign_CALL() {
    try {
      const formData = new FormData(forM); 
  
      const response = await fetch("http://localhost:8080/chamados", {
        method: "POST",
        body: formData,
      });
  
      const response_convert = await response.json();
  
      if (response_convert.message !== undefined) {
        alert(response_convert.message);
      } else {
        alert("CHAMADO ENVIADO.");
      }
    } catch (error) {
      alert("ERRO AO ENVIAR: " + error.message);
    }
  }