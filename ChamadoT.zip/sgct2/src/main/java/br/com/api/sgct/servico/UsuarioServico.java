package br.com.api.sgct.servico;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.api.sgct.modelo.Usuario;
import br.com.api.sgct.repositorio.UsuarioRepositorio;

@Service
public class UsuarioServico {
    @Autowired
    private UsuarioRepositorio ur;

    public List<Usuario> listartodos(){
        return ur.findAll();
    }

    public Optional<Usuario> buscarPorId(Long id){
        return ur.findById(id);
    }

    public Usuario salvar(Usuario usuario){
        return ur.save(usuario);
    }

    public void deletar(Long id){
        ur.deleteById(id);
    }

    public Optional<Usuario> autenticar(String nome, String senha){
        return ur.findByNomeAndSenha(nome, senha);
    }
}
