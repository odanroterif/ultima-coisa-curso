package br.com.api.sgct.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.api.sgct.modelo.Chamado;

@Repository
public interface ChamadoRepositorio extends JpaRepository<Chamado, Long> {


    
    
}
