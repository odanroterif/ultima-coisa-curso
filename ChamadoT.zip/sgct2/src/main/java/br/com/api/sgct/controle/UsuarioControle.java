package br.com.api.sgct.controle;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import br.com.api.sgct.LoginDTO;
import br.com.api.sgct.modelo.Usuario;
import br.com.api.sgct.servico.UsuarioServico;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/usuarios")
public class UsuarioControle {
    @Autowired
    private UsuarioServico us;

    @GetMapping
    public List<Usuario> listar(){
        return us.listartodos();
    }

    @GetMapping("/{id}")
    public Optional<Usuario> buscar(@PathVariable Long id){
        return us.buscarPorId(id);
    }

    @PostMapping
    public Usuario criar(@RequestBody Usuario usuario){
        return us.salvar(usuario);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id){
        us.deletar(id);
    }
    
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginDTO loginDTO){
        Optional<Usuario> usuario = us.autenticar(loginDTO.getNome(), loginDTO.getSenha());

        if (usuario.isPresent()) {
            return ResponseEntity.ok(usuario.get());
        } else {
            return ResponseEntity.status(401).body("Usuário ou senha inválidos");
        }
    }
}
