package br.com.api.sgct.servico;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.api.sgct.modelo.Categoria;
import br.com.api.sgct.repositorio.CategoriaRepositorio;

@Service
public class CategoriaServico {
    
    @Autowired
    CategoriaRepositorio cr;

    public List<Categoria> listarCategorias(){
        return cr.findAll();
    }

    public Optional<Categoria> buscarPorId(Long id){
        return cr.findById(id);
    }
    
    public Categoria salvar(Categoria categoria){
        return cr.save(categoria);
    }

    public void deletar(Long id){
        cr.deleteById(id);
    }
}
