package br.com.api.sgct.modelo;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "chamado")
@Getter
@Setter
public class Chamado {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idchamado;
    
    private String titulo;
    private String descricao;
    private String status;
    private String prioridade;

    @Column(name = "data_criado", nullable = false)
    private LocalDateTime dataCriado = LocalDateTime.now();

    @Column(name = "data_terminado", nullable = true)
    private LocalDate dataTerminado;

    @ManyToOne
    @JoinColumn(name = "usuario_idusuario")
    private Usuario usuario;

    @ManyToOne
    @JoinColumn(name = "categoria_idcategoria")
    private Categoria category;
}