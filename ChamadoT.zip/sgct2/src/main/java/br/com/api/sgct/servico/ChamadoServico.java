package br.com.api.sgct.servico;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import br.com.api.sgct.modelo.Chamado;
import br.com.api.sgct.repositorio.ChamadoRepositorio;

@Service
public class ChamadoServico {
    
    @Autowired
    private ChamadoRepositorio cr;

    public List<Chamado> listartodos(){
        return cr.findAll();
    }

    public Optional<Chamado> buscarPorId(Long id){
        return cr.findById(id);
    }

    public ResponseEntity<?> salvar(Chamado chamado){
        return new ResponseEntity<Chamado>(cr.save(chamado),HttpStatus.CREATED);
    }

    public void deletar(Long id){
        cr.deleteById(id);
    }
}
