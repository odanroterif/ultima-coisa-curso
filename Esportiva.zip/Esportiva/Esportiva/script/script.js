let produtos = [
    { nome: 'Bola de Futebol', categoria: 'Futebol', preco: '89,90' },
    { nome: 'Tênis de Corrida', categoria: 'Corrida', preco: '299,90' },
    { nome: 'Camiseta Dry Fit', categoria: 'Roupas', preco: '59,90' }
  ];

  function renderProdutos() {
    const perfil = sessionStorage.getItem('perfilUsuario');
    const tabela = document.getElementById('tabelaProdutos');
    tabela.innerHTML = '';
    produtos.forEach((p, index) => {
      if (
        (perfil === 'operacional' && p.categoria !== 'Futebol' && p.categoria !== 'Corrida') ||
        (perfil === 'tecnico' && p.categoria !== 'Roupas')
      ) return;
      tabela.innerHTML += `<tr><td>${p.nome}</td><td>${p.categoria}</td><td>R$ ${p.preco}</td><td class="actions"><button class="edit" onclick="editarProduto(${index})">✏️</button><button class="delete" onclick="removerProduto(${index})">✖</button></td></tr>`;
    });
  }

  function gerarRelatorioPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const perfil = sessionStorage.getItem('perfilUsuario');
    doc.setFontSize(16);
    doc.text('Relatório de Produtos Esportivos', 20, 20);
    let y = 40;
    produtos.forEach((p) => {
      if (
        (perfil === 'operacional' && p.categoria !== 'Futebol' && p.categoria !== 'Corrida') ||
        (perfil === 'tecnico' && p.categoria !== 'Roupas')
      ) return;
      doc.setFontSize(12);
      doc.text(`${p.nome} - ${p.categoria} - R$ ${p.preco}`, 20, y);
      y += 10;
    });
    const dataHora = new Date().toLocaleString();
    doc.setFontSize(10);
    doc.text(`Gerado em: ${dataHora}`, 20, y + 20);
    doc.save('relatorio_produtos.pdf');
  }

  function adicionarProduto() {
    const nome = prompt("Nome do produto:");
    const categoria = prompt("Categoria:");
    const preco = prompt("Preço:");
    if (nome && categoria && preco) {
      produtos.push({ nome, categoria, preco });
      renderProdutos();
    }
  }

  function editarProduto(index) {
    const nome = prompt("Novo nome:", produtos[index].nome);
    const categoria = prompt("Nova categoria:", produtos[index].categoria);
    const preco = prompt("Novo preço:", produtos[index].preco);
    if (nome && categoria && preco) {
      produtos[index] = { nome, categoria, preco };
      renderProdutos();
    }
  }

  function removerProduto(index) {
    if (confirm("Deseja remover este produto?")) {
      produtos.splice(index, 1);
      renderProdutos();
    }
  }

  function mostrarCadastro() {
    document.getElementById('telaLogin').classList.add('hidden');
    document.getElementById('telaCadastro').classList.remove('hidden');
  }

  function mostrarLogin() {
    document.getElementById('telaCadastro').classList.add('hidden');
    document.getElementById('telaLogin').classList.remove('hidden');
  }

  function cadastrarUsuario() {
    const nome = document.getElementById('cadastroNome').value;
    const email = document.getElementById('cadastroEmail').value;
    const senha = document.getElementById('cadastroSenha').value;
    const perfil = document.getElementById('cadastroPerfil').value;
    if (!nome || !email || !senha) {
      alert("Preencha todos os campos!");
      return;
    }
    const usuario = { nome, email, senha, perfil };
    let usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];
    usuarios.push(usuario);
    localStorage.setItem('usuarios', JSON.stringify(usuarios));
    alert("Usuário cadastrado com sucesso!");
    mostrarLogin();
  }

  function logar() {
    const email = document.getElementById('loginUsuario').value;
    const senha = document.getElementById('loginSenha').value;
    const usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];
    const usuario = usuarios.find(u => u.email === email && u.senha === senha);
    if (usuario) {
      sessionStorage.setItem('perfilUsuario', usuario.perfil);
      document.getElementById('telaLogin').classList.add('hidden');
      document.getElementById('telaSistema').classList.remove('hidden');
      renderProdutos();
    } else {
      alert("Usuário ou senha inválidos!");
    }
  }

  function logout() {
    sessionStorage.clear();
    document.getElementById('telaSistema').classList.add('hidden');
    document.getElementById('telaLogin').classList.remove('hidden');
  }