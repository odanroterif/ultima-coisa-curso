﻿using aaa.models;
using Microsoft.EntityFrameworkCore;
using System;

namespace aaa.data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions options) : base(options) { }

        public DbSet<Animals> ATcrud { get; set; }
    }
}
